// SERVIYA - JavaScript para funcionalidad completa
class ServiyaApp {
    constructor() {
        this.appointments = this.loadAppointments();
        this.selectedService = '';
        this.init();
    }

    init() {
        this.setupTabs();
        this.setupForm();
        this.setupServiceSelection();
        this.renderAppointments();
        this.updateSummary();
        this.setMinDate();
    }

    // Tab Management
    setupTabs() {
        const tabTriggers = document.querySelectorAll('.tab-trigger');
        const tabContents = document.querySelectorAll('.tab-content');

        tabTriggers.forEach(trigger => {
            trigger.addEventListener('click', () => {
                const tabName = trigger.getAttribute('data-tab');

                // Remove active class from all triggers and contents
                tabTriggers.forEach(t => t.classList.remove('active'));
                tabContents.forEach(c => c.classList.remove('active'));

                // Add active class to clicked trigger and corresponding content
                trigger.classList.add('active');
                const targetContent = document.getElementById(`${tabName}-content`);
                if (targetContent) {
                    targetContent.classList.add('active');
                }

                // Update appointments display when switching to appointments tab
                if (tabName === 'appointments') {
                    this.renderAppointments();
                    this.updateSummary();
                }
            });
        });
    }

    // Service Selection
    setupServiceSelection() {
        const serviceOptions = document.querySelectorAll('.service-option');

        serviceOptions.forEach(option => {
            option.addEventListener('click', () => {
                // Remove selected class from all options
                serviceOptions.forEach(opt => opt.classList.remove('selected'));

                // Add selected class to clicked option
                option.classList.add('selected');

                // Store selected service
                this.selectedService = option.getAttribute('data-service');
            });
        });
    }

    // Form Management
    setupForm() {
        const form = document.getElementById('appointmentForm');
        const urgentCheckbox = document.getElementById('urgent');
        const submitText = document.getElementById('submitText');

        // Handle urgent checkbox
        urgentCheckbox.addEventListener('change', (e) => {
            if (e.target.checked) {
                submitText.textContent = '🚨 Solicitar Servicio de Emergencia';
            } else {
                submitText.textContent = '📅 Agendar Cita';
            }
        });

        // Handle form submission
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleFormSubmit();
        });
    }

    handleFormSubmit() {
        const formData = new FormData(document.getElementById('appointmentForm'));

        // Validation
        if (!this.validateForm(formData)) {
            return;
        }

        // Create appointment object
        const appointment = {
            id: Date.now().toString(),
            name: formData.get('name'),
            phone: formData.get('phone'),
            email: formData.get('email') || '',
            address: formData.get('address'),
            serviceType: this.selectedService,
            problemType: formData.get('problemType') || '',
            description: formData.get('description') || '',
            date: new Date(formData.get('date')),
            time: formData.get('time'),
            status: formData.get('urgent') ? 'urgente' : 'programada',
            createdAt: new Date()
        };

        // Add to appointments
        this.appointments.push(appointment);
        this.saveAppointments();

        // Show success message
        if (appointment.status === 'urgente') {
            this.showToast(
                '🚨 Solicitud de emergencia recibida',
                'Un técnico se comunicará con usted en los próximos 30 minutos.',
                'success'
            );
        } else {
            this.showToast(
                '✅ Cita agendada exitosamente',
                `Su cita está programada para el ${appointment.date.toLocaleDateString('es-ES')} a las ${appointment.time}`,
                'success'
            );
        }

        // Reset form and switch to appointments tab
        this.resetForm();
        this.switchToTab('appointments');
        this.renderAppointments();
        this.updateSummary();
    }

    validateForm(formData) {
        const requiredFields = ['name', 'phone', 'address', 'date', 'time'];

        for (const field of requiredFields) {
            if (!formData.get(field)) {
                this.showToast(
                    'Error en el formulario',
                    'Por favor complete todos los campos obligatorios',
                    'error'
                );
                return false;
            }
        }

        if (!this.selectedService) {
            this.showToast(
                'Error en el formulario',
                'Por favor seleccione un tipo de servicio',
                'error'
            );
            return false;
        }

        return true;
    }

    resetForm() {
        document.getElementById('appointmentForm').reset();

        // Clear service selection
        document.querySelectorAll('.service-option').forEach(opt => {
            opt.classList.remove('selected');
        });
        this.selectedService = '';

        // Reset submit button text
        document.getElementById('submitText').textContent = '📅 Agendar Cita';
    }

    // Appointments Management
    renderAppointments() {
        const appointmentsList = document.getElementById('appointmentsList');
        const appointmentsBadge = document.getElementById('appointmentsBadge');

        if (this.appointments.length === 0) {
            appointmentsList.innerHTML = `
                <div class="empty-state">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M8 2v4"/>
                        <path d="M16 2v4"/>
                        <rect width="18" height="18" x="3" y="4" rx="2"/>
                        <path d="M3 10h18"/>
                    </svg>
                    <h3>No hay citas programadas</h3>
                    <p>Las citas que agende aparecerán aquí</p>
                </div>
            `;
            appointmentsBadge.style.display = 'none';
            return;
        }

        // Show badge with count
        const activeCount = this.appointments.filter(a =>
            a.status === 'programada' || a.status === 'urgente'
        ).length;

        if (activeCount > 0) {
            appointmentsBadge.textContent = activeCount;
            appointmentsBadge.style.display = 'inline-block';
        } else {
            appointmentsBadge.style.display = 'none';
        }

        // Sort appointments (urgent first, then by date)
        const sortedAppointments = [...this.appointments].sort((a, b) => {
            if (a.status === 'urgente' && b.status !== 'urgente') return -1;
            if (b.status === 'urgente' && a.status !== 'urgente') return 1;
            return new Date(a.date) - new Date(b.date);
        });

        appointmentsList.innerHTML = sortedAppointments.map(appointment =>
            this.createAppointmentHTML(appointment)
        ).join('');

        // Add event listeners for action buttons
        this.setupAppointmentActions();
    }

    createAppointmentHTML(appointment) {
        const serviceInfo = this.getServiceInfo(appointment.serviceType);
        const statusInfo = this.getStatusInfo(appointment.status);

        return `
            <div class="appointment-item" data-id="${appointment.id}">
                <div class="appointment-header">
                    <div class="appointment-info">
                        <div class="service-icon-wrapper ${appointment.serviceType}">
                            ${serviceInfo.icon}
                        </div>
                        <div>
                            <h4>${appointment.name}</h4>
                            <div class="appointment-badges">
                                <div class="status-badge ${appointment.status}">
                                    ${statusInfo.icon}
                                    ${statusInfo.label}
                                </div>
                                <div class="service-badge">
                                    ${serviceInfo.name}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="appointment-datetime">
                        <div>
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M8 2v4"/>
                                <path d="M16 2v4"/>
                                <rect width="18" height="18" x="3" y="4" rx="2"/>
                                <path d="M3 10h18"/>
                            </svg>
                            ${appointment.date.toLocaleDateString('es-ES')}
                        </div>
                        <div>
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"/>
                                <polyline points="12,6 12,12 16,14"/>
                            </svg>
                            ${appointment.time}
                        </div>
                    </div>
                </div>
                
                <div class="appointment-details">
                    <div class="detail-item">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                        </svg>
                        <span>${appointment.phone}</span>
                    </div>
                    ${appointment.email ? `
                        <div class="detail-item">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                                <polyline points="22,6 12,13 2,6"/>
                            </svg>
                            <span>${appointment.email}</span>
                        </div>
                    ` : ''}
                    <div class="detail-item" style="grid-column: 1 / -1;">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <pin d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
                            <circle cx="12" cy="10" r="3"/>
                        </svg>
                        <span>${appointment.address}</span>
                    </div>
                </div>

                ${appointment.problemType || appointment.description ? `
                    <div class="appointment-problem">
                        ${appointment.problemType ? `
                            <div>
                                <span>Tipo de problema:</span> ${appointment.problemType}
                            </div>
                        ` : ''}
                        ${appointment.description ? `
                            <div>
                                <span>Descripción:</span>
                                <p>${appointment.description}</p>
                            </div>
                        ` : ''}
                    </div>
                ` : ''}

                ${appointment.status !== 'completada' && appointment.status !== 'cancelada' ? `
                    <div class="appointment-actions">
                        <button class="btn-small" onclick="app.updateStatus('${appointment.id}', 'completada')">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                                <polyline points="22,4 12,14.01 9,11.01"/>
                            </svg>
                            Completar
                        </button>
                        <button class="btn-small" onclick="app.updateStatus('${appointment.id}', 'cancelada')">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"/>
                                <path d="m15 9-6 6"/>
                                <path d="m9 9 6 6"/>
                            </svg>
                            Cancelar
                        </button>
                        <button class="btn-small btn-delete" onclick="app.deleteAppointment('${appointment.id}')">
                            Eliminar
                        </button>
                    </div>
                ` : ''}
            </div>
        `;
    }

    setupAppointmentActions() {
        // Actions are handled via onclick attributes in the HTML
        // This method can be used for additional setup if needed
    }

    updateStatus(id, status) {
        const appointment = this.appointments.find(a => a.id === id);
        if (appointment) {
            appointment.status = status;
            this.saveAppointments();

            const statusMessages = {
                completada: '✅ Cita marcada como completada',
                cancelada: '❌ Cita cancelada',
                programada: '📅 Cita reprogramada',
                urgente: '🚨 Cita marcada como emergencia'
            };

            this.showToast('Estado actualizado', statusMessages[status], 'success');
            this.renderAppointments();
            this.updateSummary();
        }
    }

    deleteAppointment(id) {
        if (confirm('¿Está seguro de que desea eliminar esta cita?')) {
            this.appointments = this.appointments.filter(a => a.id !== id);
            this.saveAppointments();
            this.showToast('Cita eliminada', '🗑️ Cita eliminada exitosamente', 'success');
            this.renderAppointments();
            this.updateSummary();
        }
    }

    // Summary Cards
    updateSummary() {
        const summaryCards = document.getElementById('summaryCards');
        const scheduledCount = this.appointments.filter(a => a.status === 'programada').length;
        const emergencyCount = this.appointments.filter(a => a.status === 'urgente').length;
        const totalCount = this.appointments.length;

        if (totalCount > 0) {
            summaryCards.style.display = 'grid';
            document.getElementById('scheduledCount').textContent = scheduledCount;
            document.getElementById('emergencyCount').textContent = emergencyCount;
            document.getElementById('totalCount').textContent = totalCount;
        } else {
            summaryCards.style.display = 'none';
        }
    }

    // Utility Methods
    getServiceInfo(serviceType) {
        const services = {
            agua: {
                name: 'Plomería y Agua',
                icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-10 6L2 8Z"/>
                    <path d="m2 8 10-6 10 6-10 6L2 8Z"/>
                </svg>`
            },
            luz: {
                name: 'Electricidad',
                icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polygon points="13,2 3,14 12,14 11,22 21,10 12,10 13,2"/>
                </svg>`
            },
            gas: {
                name: 'Gas',
                icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>
                </svg>`
            },
            carpinteria: {
                name: 'Carpintería',
                icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="m15 12-8.5-8.5c-.83-.83-2.17-.83-3 0 0 0 0 0 0 0a2.12 2.12 0 0 0 0 3L12 15l3-3Z"/>
                    <path d="M17.64 15 22 10.64"/>
                </svg>`
            },
            pintura: {
                name: 'Pintura',
                icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="m14.622 17.897-10.68-2.913"/>
                    <path d="M18.376 2.622a1 1 0 1 1 3.002 3.002L17.36 9.643a.5.5 0 0 0 0 .707l.944.944a2.41 2.41 0 0 1 0 3.408l-.944.944a.5.5 0 0 1-.707 0L8.354 7.348a.5.5 0 0 1 0-.707l.944-.944a2.41 2.41 0 0 1 3.408 0l.944.944a.5.5 0 0 0 .707 0l4.018-4.018z"/>
                </svg>`
            },
            aire: {
                name: 'Aire A/C',
                icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/>
                    <path d="M9.6 4.6A2 2 0 1 1 11 8H2"/>
                    <path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>
                </svg>`
            },
            cerrajeria: {
                name: 'Cerrajería',
                icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="8" cy="15" r="4"/>
                    <path d="m8.5 12.5-5.957-2.337A1 1 0 0 1 3.043 8.82l14.354-5.457a1 1 0 0 1 1.31 1.31l-5.457 14.354a1 1 0 0 1-1.343.5L8.5 12.5"/>
                </svg>`
            },
            electrodomesticos: {
                name: 'Electrodomésticos',
                icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M5 6a4 4 0 0 1 4-4h6a4 4 0 0 1 4 4v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6Z"/>
                    <circle cx="12" cy="11" r="2"/>
                    <path d="M9 16h6"/>
                </svg>`
            },
            jardineria: {
                name: 'Jardinería',
                icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="m17 14 3 3.3a1 1 0 0 1-.7 1.7H4.7a1 1 0 0 1-.7-1.7L7 14h-.3a1 1 0 0 1-.7-1.7L9 9h-.2A1 1 0 0 1 8 7.3L11 4l3 3.3a1 1 0 0 1-.8 1.7H13l3 3.3a1 1 0 0 1-.7 1.7H17Z"/>
                </svg>`
            },
            limpieza: {
                name: 'Limpieza',
                icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="m9.06 11.9 8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08"/>
                    <path d="m7.07 14.94-1.13 1.13a3.5 3.5 0 1 1-4.95-4.95l1.13-1.13"/>
                    <path d="m12 15 3.5 3.5-8 8-3.5-3.5 8-8Z"/>
                </svg>`
            }
        };

        return services[serviceType] || { name: serviceType, icon: '' };
    }

    getStatusInfo(status) {
        const statuses = {
            programada: {
                label: 'Programada',
                icon: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M8 2v4"/>
                    <path d="M16 2v4"/>
                    <rect width="18" height="18" x="3" y="4" rx="2"/>
                    <path d="M3 10h18"/>
                </svg>`
            },
            urgente: {
                label: 'Emergencia',
                icon: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/>
                    <path d="M12 9v4"/>
                    <path d="m12 17 .01 0"/>
                </svg>`
            },
            completada: {
                label: 'Completada',
                icon: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                    <polyline points="22,4 12,14.01 9,11.01"/>
                </svg>`
            },
            cancelada: {
                label: 'Cancelada',
                icon: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="m15 9-6 6"/>
                    <path d="m9 9 6 6"/>
                </svg>`
            }
        };

        return statuses[status] || { label: status, icon: '' };
    }

    switchToTab(tabName) {
        const tabTrigger = document.querySelector(`[data-tab="${tabName}"]`);
        if (tabTrigger) {
            tabTrigger.click();
        }
    }

    setMinDate() {
        const dateInput = document.getElementById('date');
        if (dateInput) {
            const today = new Date();
            const year = today.getFullYear();
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const day = String(today.getDate()).padStart(2, '0');
            dateInput.min = `${year}-${month}-${day}`;
        }
    }

    // Toast Notifications
    showToast(title, description, type = 'success') {
        const toastContainer = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;

        toast.innerHTML = `
            <div class="toast-title">${title}</div>
            <div class="toast-description">${description}</div>
        `;

        toastContainer.appendChild(toast);

        // Auto remove after 5 seconds
        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 300);
        }, 5000);
    }

    // Local Storage Management
    saveAppointments() {
        localStorage.setItem('serviya_appointments', JSON.stringify(this.appointments));
    }

    loadAppointments() {
        const stored = localStorage.getItem('serviya_appointments');
        if (stored) {
            const appointments = JSON.parse(stored);
            // Convert date strings back to Date objects
            return appointments.map(appointment => ({
                ...appointment,
                date: new Date(appointment.date),
                createdAt: new Date(appointment.createdAt)
            }));
        }
        return [];
    }
}

// Initialize the application when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new ServiyaApp();
});

// Add CSS animation for toast slideOut
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);